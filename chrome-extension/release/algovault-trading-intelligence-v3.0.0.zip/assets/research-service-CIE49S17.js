import{b as C}from"./algovault-DDfYIqg6.js";import{P as w,D as h,d as R,E as g,z as b,y as S,F as E,A as O}from"./storage-D3h1hYof.js";function m(e,t){return`${(e||"").toUpperCase()}|${t||"-"}`}function v(e){return w.find(t=>t.id===e)??w[0]}async function T(e,t){const a=m(e,t);return(await h()).find(n=>n.key===a)??null}async function Y(e=12){return(await h()).sort((a,s)=>s.updatedAt-a.updatedAt).slice(0,e)}async function N(e){const t=await h(),a=t.findIndex(s=>s.id===e.id);a>=0?t[a]=e:t.unshift(e),await S(t)}async function V(e,t){const a=m(e,t),n=(await h()).filter(u=>u.key!==a);await S(n);const o=await g();o[a]&&(delete o[a],await b(o))}async function A(e,t){return(await g())[m(e,t)]??null}function x(e){var a,s,n;if(!e||!e.bias&&!e.plan&&!((a=e.keyLevels)!=null&&a.length))return"";const t=["===== PRIOR SESSION MEMORY (what you concluded before) ====="];return e.bias&&t.push(`Bias: ${e.bias}`),(s=e.keyLevels)!=null&&s.length&&t.push(`Key levels: ${e.keyLevels.join("; ")}`),e.plan&&t.push(`Active plan: ${e.plan}`),(n=e.notes)!=null&&n.length&&t.push(`Notes: ${e.notes.slice(-5).join("; ")}`),t.push("Stay consistent with this memory unless the fresh chart context contradicts it — if it does, say what changed."),t.push("===== END MEMORY ====="),`

${t.join(`
`)}`}function D(e,t){const a=[],s=/^(?:key\s+)?levels?\s*:?\s*(.+)$/im,n=e.match(s);n&&a.push(n[1].slice(0,220));const o=e.trim().split(/\n{2,}/).slice(-2).join(" ").slice(0,500);return{bias:t==null?void 0:t.bias,keyLevels:a.length?a:t==null?void 0:t.keyLevels,plan:o||(t==null?void 0:t.plan),notes:t==null?void 0:t.notes,updatedAt:Date.now()}}function M(e){if(!e)return"";const t=["===== ALGOVAULT USER REPOSITORY MEMORY =====",`Saved Strategies in Library: ${e.savedStrategiesCount}`,`Saved Custom Indicators: ${e.savedIndicatorsCount}`,`Active Setups in Monitoring: ${e.activeSetupsCount}`,`Completed Research Analyses: ${e.recentAnalysesCount}`];return e.similarSavedStrategies&&e.similarSavedStrategies.length>0&&(t.push("Similar Saved Strategies in Playbook:"),e.similarSavedStrategies.forEach(a=>{var s;t.push(`- Strategy: ${a.name}`),(s=a.reasons)==null||s.forEach(n=>t.push(`  * ${n}`))})),e.similarHistoricalResearch&&e.similarHistoricalResearch.length>0&&(t.push("Similar Historical Research Results:"),e.similarHistoricalResearch.forEach(a=>{t.push(`- ${a.title}: ${a.outcome}`)})),e.recentDismissedSetups&&e.recentDismissedSetups.length>0&&(t.push("Recent Dismissed / Invalidated Setups:"),e.recentDismissedSetups.forEach(a=>{t.push(`- ${a.setupType} (invalidated / dismissed)`)})),t.push("Standard: Explain WHY setups resemble the user's playbook (same structure, indicators, timeframe, liquidity) when relevant. Never imply similarity guarantees future results."),t.push("===== END ALGOVAULT USER MEMORY ====="),`

${t.join(`
`)}`}async function W(e){var c,p;const t=await R(),a=v(t.personaId),s=m(e.symbol,e.timeframe),n=e.withHistory!==!1?((c=await T(e.symbol,e.timeframe))==null?void 0:c.messages.slice(-12))??[]:[],o=await A(e.symbol,e.timeframe),u=e.structuredContext?`

===== CURRENT CHART CONTEXT (canonical) =====
${e.structuredContext}
===== END CONTEXT =====`:`

===== CURRENT CHART CONTEXT =====
No active chart context available. Work from general knowledge and never fabricate prices.
===== END CONTEXT =====`,d=n.map(l=>({role:l.role,content:l.content}));d.push({role:"user",content:`${e.question}${x(o)}${M(e.algoVaultMemory??null)}${u}`});const r=await C(d.map((l,f)=>({...l,timestamp:f})),a.systemPrompt,8e3,e.contextObject,t.model||void 0);let i=null;try{const l=await T(e.symbol,e.timeframe),f={id:`m${Date.now()}u`,role:"user",content:e.question,at:Date.now(),personaId:a.id},$={id:`m${Date.now()}a`,role:"assistant",content:r.content,at:Date.now(),model:r.model??t.model??null,personaId:a.id};i=l??{id:`t${Date.now()}`,key:s,symbol:e.symbol.toUpperCase(),timeframe:e.timeframe,title:`${e.symbol.toUpperCase()} ${e.timeframe}`,messages:[],createdAt:Date.now(),updatedAt:Date.now()},i.messages=[...i.messages,f,$].slice(-200),i.updatedAt=Date.now(),await N(i);const y=await g();y[s]=D(r.content,y[s]??null),await b(y),(p=e.onThreadUpdate)==null||p.call(e,i)}catch{}return{answer:r.content,model:r.model??t.model??null,thread:i}}const I=1800*1e3,P=360*60*1e3,U=`You are AlgoVault Research. Produce a compact research snapshot for the symbol in the chart context.

Structure exactly these sections with markdown headings:
## Snapshot
2-3 sentences: what the asset is doing right now (trend, momentum, volatility) — strictly from the CHART CONTEXT data.
## Technicals
Bullet list: trend direction, structure (BOS/CHOCH counts), RSI/EMA/VWAP readings if present in context, volatility state. Use ONLY values present in the context.
## Sentiment & Narrative
2-3 bullets on the current market narrative for this asset class. General knowledge — keep it qualitative, no invented numbers.
## Key Risks
2-3 bullets.
## Bottom line
One paragraph: the actionable takeaway and what would change it.

Never fabricate prices, indicator values or fundamental figures. If the chart context lacks data, say what is missing.`,H=`You are AlgoVault Research. Produce a structured research report for the symbol in the chart context.

Sections (markdown headings):
## Overview
What the asset is, and how it has been behaving — from the CHART CONTEXT.
## Multi-horizon Read
Bullets for intraday / swing / positional horizon based on the context timeframes and trend data. Strictly from context values.
## Fundamentals & Macro Context
Qualitative drivers for this asset class (e.g. rates & DXY for FX metals, ETF flows & halvings for BTC, earnings & margins for equities). General knowledge — explicitly qualitative, no invented figures.
## Technical Roadmap
Key levels FROM THE CONTEXT: supports, resistances, liquidity zones, VWAP, structure triggers. Mark each as bullish/bearish trigger.
## Scenarios
Bull case, bear case, and the trigger that separates them.
## Risks & What Would Invalidate
Bullets.
## Research Notes
2-4 open questions a trader should verify (upcoming events, data gaps in context).

Never fabricate prices, indicator values, earnings numbers or dates. If the context lacks data, say exactly what is missing.`,L={quick:I,deep:P};function k(e,t){return`${(e||"").toUpperCase()}|${t}`}async function B(e,t){return(await E())[k(e,t)]??null}async function j(e){const{symbol:t,kind:a}=e;if(!e.force){const c=await B(t,a);if(c&&Date.now()-c.generatedAt<=L[a])return c}const s=await R(),n=v(s.personaId),o=e.structuredContext?`

===== CHART CONTEXT (canonical, live) =====
${e.structuredContext}
===== END CONTEXT =====`:`

===== CHART CONTEXT =====
No live chart context available for this symbol. Note this prominently in the Snapshot section.
===== END CONTEXT =====`,u=`${e.kind==="quick"?U:H}

Research target: ${t.toUpperCase()} (chart timeframe ${e.timeframe}).${o}`,d=await C([{role:"user",content:u,timestamp:Date.now()}],n.systemPrompt,e.kind==="deep"?8e3:3e3,e.contextObject,s.model||void 0),r={symbol:t.toUpperCase(),kind:a,content:d.content,model:d.model??s.model??null,generatedAt:Date.now(),personaId:n.id},i=await E();return i[k(t,a)]=r,await O(i),r}export{Y as a,W as b,V as c,B as d,j as g,T as l,v as p};
