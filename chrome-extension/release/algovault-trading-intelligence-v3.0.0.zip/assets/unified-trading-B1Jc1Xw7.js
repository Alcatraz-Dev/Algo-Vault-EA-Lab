var w=Object.defineProperty;var R=(e,t,n)=>t in e?w(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n;var g=(e,t,n)=>R(e,typeof t!="symbol"?t+"":t,n);import{i as c,R as N,j as T,g as x}from"./storage-D3h1hYof.js";import{j as r}from"./theme-DhJLbfqP.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=c("Activity",[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=c("Bell",[["path",{d:"M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9",key:"1qo2s2"}],["path",{d:"M10.3 21a1.94 1.94 0 0 0 3.4 0",key:"qgo35s"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=c("Bot",[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W=c("Brain",[["path",{d:"M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z",key:"l5xja"}],["path",{d:"M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z",key:"ep3f8r"}],["path",{d:"M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4",key:"1p4c4q"}],["path",{d:"M17.599 6.5a3 3 0 0 0 .399-1.375",key:"tmeiqw"}],["path",{d:"M6.003 5.125A3 3 0 0 0 6.401 6.5",key:"105sqy"}],["path",{d:"M3.477 10.896a4 4 0 0 1 .585-.396",key:"ql3yin"}],["path",{d:"M19.938 10.5a4 4 0 0 1 .585.396",key:"1qfode"}],["path",{d:"M6 18a4 4 0 0 1-1.967-.516",key:"2e4loj"}],["path",{d:"M19.967 17.484A4 4 0 0 1 18 18",key:"159ez6"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=c("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V=c("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K=c("ChevronUp",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=c("CircleAlert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const X=c("CircleCheck",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J=c("ClipboardList",[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"M12 11h4",key:"1jrz19"}],["path",{d:"M12 16h4",key:"n85exb"}],["path",{d:"M8 11h.01",key:"1dfujw"}],["path",{d:"M8 16h.01",key:"18s6g9"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y=c("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z=c("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q=c("ExternalLink",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ee=c("FlaskConical",[["path",{d:"M10 2v7.527a2 2 0 0 1-.211.896L4.72 20.55a1 1 0 0 0 .9 1.45h12.76a1 1 0 0 0 .9-1.45l-5.069-10.127A2 2 0 0 1 14 9.527V2",key:"pzvekw"}],["path",{d:"M8.5 2h7",key:"csnxdl"}],["path",{d:"M7 16h10",key:"wp8him"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const te=c("Info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ne=c("Layers",[["path",{d:"m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z",key:"8b97xw"}],["path",{d:"m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65",key:"dd6zsq"}],["path",{d:"m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65",key:"ep9fru"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const se=c("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ae=c("Lock",[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const oe=c("MessageSquareText",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}],["path",{d:"M13 8H7",key:"14i4kc"}],["path",{d:"M17 12H7",key:"16if0g"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ce=c("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=c("Pencil",[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ie=c("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=c("Radar",[["path",{d:"M19.07 4.93A10 10 0 0 0 6.99 3.34",key:"z3du51"}],["path",{d:"M4 6h.01",key:"oypzma"}],["path",{d:"M2.29 9.62A10 10 0 1 0 21.31 8.35",key:"qzzz0"}],["path",{d:"M16.24 7.76A6 6 0 1 0 8.23 16.67",key:"1yjesh"}],["path",{d:"M12 18h.01",key:"mhygvu"}],["path",{d:"M17.99 11.66A6 6 0 0 1 15.77 16.67",key:"1u2y91"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}],["path",{d:"m13.41 10.59 5.66-5.66",key:"mhq4k0"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const de=c("RefreshCw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ue=c("Send",[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const he=c("ShieldCheck",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ye=c("Sparkles",[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pe=c("Target",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fe=c("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ke=c("TrendingDown",[["polyline",{points:"22 17 13.5 8.5 8.5 13.5 2 7",key:"1r2t7k"}],["polyline",{points:"16 17 22 17 22 11",key:"11uiuu"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ge=c("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ee=c("Wallet",[["path",{d:"M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",key:"18etb6"}],["path",{d:"M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4",key:"xoc0q4"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const me=c("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]),I=/\*\*([^*]+)\*\*/g,O=/(^|[^*])\*([^*\s][^*]*?)\*(?!\*)/g;function E(e,t){const n=e.split(/(`[^`]+`)/g),s=[];return n.forEach((a,o)=>{if(a.startsWith("`")&&a.endsWith("`")&&a.length>2){s.push(r.jsx("code",{style:{background:"rgba(139, 92, 246, 0.12)",padding:"0 4px",borderRadius:4,fontFamily:"monospace",fontSize:"0.92em",color:"#c4b5fd"},children:a.slice(1,-1)},`${t}-c${o}`));return}a.split(I).forEach((i,l)=>{if(l%2===1){s.push(r.jsx("strong",{style:{fontWeight:700,color:"#f9f9f9"},children:i},`${t}-b${o}-${l}`));return}i.split(O).forEach((u,y)=>{y%3===1&&u?s.push(r.jsx("em",{style:{fontStyle:"italic",color:"#d6d6e8"},children:u},`${t}-i${o}-${l}-${y}`)):u&&s.push(r.jsx(N.Fragment,{children:u},`${t}-f${o}-${l}-${y}`))})})}),s}function b(e,t){return t?`${e}.`:"•"}function Me({content:e}){const t=e.split(/\n{2,}/);return r.jsx("div",{style:{wordBreak:"break-word",whiteSpace:"pre-wrap"},children:t.map((n,s)=>{const a=n.trim();if(!a)return null;const o=a.match(/^```(\w*)\n([\s\S]*?)\n```$/);if(o)return r.jsx("pre",{style:{background:"rgba(0,0,0,0.35)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:8,padding:"8px 10px",overflowX:"auto",fontSize:10,fontFamily:"monospace",color:"#c4b5fd",marginTop:4,whiteSpace:"pre"},children:o[2]},`${s}`);if(a.startsWith("```")){const i=a.replace(/^```\w*/,"").replace(/```$/,"").trim();return r.jsx("pre",{style:{background:"rgba(0,0,0,0.35)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:8,padding:"8px 10px",overflowX:"auto",fontSize:10,fontFamily:"monospace",color:"#c4b5fd",marginTop:4,whiteSpace:"pre"},children:i},`${s}`)}const f=a.match(/^(#{1,4})\s+(.*)$/);if(f){const i=f[1].length,l=i===1?14:i===2?13:i===3?12:11;return r.jsx("div",{style:{fontSize:l,fontWeight:700,color:"#e9e4ff",marginTop:i<=2?8:4,marginBottom:4},children:E(f[2],`h${s}`)},`${s}`)}if(/^[-*•]\s+/.test(a)||/^\d+\.\s+/.test(a)){const i=/^\d+\.\s+/.test(a),l=n.split(`
`).filter(k=>k.trim());return r.jsx("div",{style:{marginTop:2,marginBottom:2},children:l.map((k,u)=>{const y=k.replace(/^[-*•]\s+/,"").replace(/^\d+\.\s+/,"").trim();return r.jsxs("div",{style:{display:"flex",gap:6,alignItems:"flex-start",marginBottom:2},children:[r.jsx("span",{style:{color:"#a78bfa",flexShrink:0},children:b(u+1,i)}),r.jsx("span",{children:E(y,`li${s}-${u}`)})]},`${u}`)})},`${s}`)}return a.startsWith(">")?r.jsx("div",{style:{borderLeft:"3px solid #7c3aed",paddingLeft:10,color:"#b8b8cf",fontStyle:"italic",margin:"4px 0"},children:E(a.replace(/^>\s?/,""),`q${s}`)},`${s}`):/^([-*_])\1{2,}$/.test(a)?r.jsx("div",{style:{borderTop:"1px solid rgba(255,255,255,0.08)",margin:"8px 0"}},`${s}`):r.jsx("p",{style:{margin:"3px 0",lineHeight:1.55},children:n.split(`
`).map((i,l)=>r.jsxs(N.Fragment,{children:[E(i,`p${s}-${l}`),l<n.split(`
`).length-1&&r.jsx("br",{})]},`${l}`))},`${s}`)})})}const Ce="Risk could not be calculated from available data.",p="Execution status could not be confirmed. Check TradingView before attempting another order.";function Ne(e){if(!e)return null;const t=String(e).replace(/\D/g,"");return t.length>=4?`••••${t.slice(-4)}`:e.length<=4?"••••":`••••${e.slice(-4)}`}function Te(){return{connectionStatus:"DISCONNECTED",accountState:"NOT_CONNECTED",broker:null,accountId:null,accountIdMasked:null,accountType:null,mode:"UNKNOWN",modeSource:"unavailable",currency:null,balance:null,equity:null,buyingPower:null,marginUsed:null,marginFree:null,marginLevel:null,tradingPermissions:[],tradingEnabled:!1,supportedOrderTypes:[],supportedActions:[],openPositions:[],pendingOrders:[],executionHistory:[],tradingView:{chartConnected:!1,chartLastSeenAt:null,mcpState:null,mcpAuthorized:null,mcpMessage:null},dataAvailability:{positions:!1,pendingOrders:!1,executionHistory:!1,reason:"No trading account connected."},lastSyncTimestamp:Date.now(),source:"unavailable",unsupportedReason:"No active trading account detected"}}const A="chrome_extension";class d extends Error{constructor(n,s){super(n);g(this,"code");g(this,"status");g(this,"result");this.name="UnifiedTradingError",this.code=s.code,this.status=s.status,this.result=s.result??null}}function Se(e="ext"){const t=Math.random().toString(36).slice(2,8);return`${e}-${Date.now().toString(36)}-${t}`}function we(e){const t=e.kind??"MARKET",n=t==="LIMIT"||t==="STOP"||t==="STOP_LIMIT";return{accountId:e.accountId,clientRequestId:e.clientRequestId,executionType:"PLACE_ORDER",symbol:e.symbol.trim().toUpperCase(),side:e.side,volume:e.volume,kind:t,price:n?e.price??null:null,stopLoss:e.stopLoss??null,takeProfit:e.takeProfit??null}}function Re(e){return{accountId:e.accountId,clientRequestId:e.clientRequestId,executionType:"MODIFY_POSITION",positionId:e.positionId,symbol:e.symbol,stopLoss:e.stopLoss??null,takeProfit:e.takeProfit??null}}function xe(e){return{accountId:e.accountId,clientRequestId:e.clientRequestId,executionType:"CLOSE_POSITION",positionId:e.positionId,symbol:e.symbol}}function Ie(e){return{accountId:e.accountId,clientRequestId:e.clientRequestId,executionType:"PARTIAL_CLOSE",positionId:e.positionId,percentage:e.percentage,symbol:e.symbol}}function Oe(e){return{accountId:e.accountId,clientRequestId:e.clientRequestId,executionType:"CANCEL_ORDER",orderId:e.orderId,symbol:e.symbol}}async function S(){const e=await x(),t={"Content-Type":"application/json"};return e&&(t.Authorization=`Bearer ${e}`),t}function M(e){return e?typeof e=="string"?{code:null,message:e}:typeof e=="object"&&typeof e.message=="string"?{code:String(e.code||"UNKNOWN_PROVIDER_ERROR"),message:e.message}:null:null}async function L(e){const t=await T();let n;try{n=await fetch(`${t}/api/trading/execute`,{method:"POST",headers:await S(),body:JSON.stringify({...e,source:A})})}catch(o){throw new d(o instanceof Error?o.message:"network_error",{code:"NETWORK",status:0,result:null})}const s=await n.json().catch(()=>null);if(!s||typeof s!="object")throw new d(`Execution service returned an unreadable response (${n.status}).`,{code:"UNREADABLE_RESPONSE",status:n.status,result:null});const a=s.result??null;if(a&&a.error&&(a.status==="REJECTED"||a.status==="FAILED"))throw new d(a.error.message,{code:a.error.code,status:n.status,result:a});if(n.status===401||n.status===403){const o=M(s.error);throw new d((o==null?void 0:o.message)??"Authentication is required.",{code:(o==null?void 0:o.code)??"PERMISSION_DENIED",status:n.status,result:a})}if(!n.ok||!s.success||!a){const o=M(s.error);throw new d((o==null?void 0:o.message)??`Execution failed (${n.status}).`,{code:(o==null?void 0:o.code)??"UNKNOWN_PROVIDER_ERROR",status:n.status,result:a})}return a}async function be(e){const t=await T(),n=new URLSearchParams({accountId:e.accountId});e.since!==void 0&&n.set("since",String(e.since));let s;try{s=await fetch(`${t}/api/trading/history?${n.toString()}`,{method:"GET",headers:await S()})}catch(o){throw new d(o instanceof Error?o.message:"network_error",{code:"NETWORK",status:0,result:null})}const a=await s.json().catch(()=>null);if(!a||typeof a!="object")throw new d(`History service returned an unreadable response (${s.status}).`,{code:"UNREADABLE_RESPONSE",status:s.status,result:null});if(!s.ok||!a.success){const o=M(a.error);throw new d((o==null?void 0:o.message)??`History request failed (${s.status}).`,{code:(o==null?void 0:o.code)??(s.status===401||s.status===403?"PERMISSION_DENIED":"UNKNOWN_PROVIDER_ERROR"),status:s.status,result:null})}return Array.isArray(a.entries)?a.entries:[]}const v=new Set(["EXECUTION_TIMEOUT"]),D="Order executed — syncing position",C="Order accepted — waiting for broker confirmation",_=new Set(["DUPLICATE_REQUEST"]);function $(e){var t,n;switch(e.status){case"SUCCEEDED":return"Order executed";case"EXECUTED_PENDING_SYNC":return D;case"ACCEPTED":return C;case"REJECTED":case"FAILED":return((t=e.error)==null?void 0:t.message)||"The order could not be executed.";case"DUPLICATE":return((n=e.error)==null?void 0:n.message)||"This order was already submitted.";default:return p}}function m(e){switch(e.code){case"NETWORK":case"UNREADABLE_RESPONSE":return p;case"EXECUTION_TIMEOUT":return`${p} (${e.message})`;case"DUPLICATE_REQUEST":return C;default:return e.message||"The order could not be executed."}}function h(e,t,n){return{status:e,ok:e==="SUCCEEDED"||e==="EXECUTED_PENDING_SYNC",duplicate:(t==null?void 0:t.duplicate)??!1,pendingSync:e==="EXECUTED_PENDING_SYNC",uncertain:e==="UNKNOWN",message:n??(t?$(t):p),result:t}}function U(e){if(e instanceof d){const t=e.result;return e.status===409&&_.has(e.code)?h("ACCEPTED",t,C):v.has(e.code)?h("UNKNOWN",t,m(e)):t&&(t.status==="FAILED"||t.status==="REJECTED")?h(t.status,t):e.status===0||e.status>=500?h("UNKNOWN",t,m(e)):h("REJECTED",t,m(e))}return h("UNKNOWN",null,p)}async function Ae(e,t=L){try{const n=await t(e);return h(n.status,n)}catch(n){return U(n)}}export{z as A,F as B,G as C,Ce as D,Q as E,ee as F,L as G,p as H,te as I,Ie as J,xe as K,ne as L,ce as M,Re as N,Oe as O,ie as P,de as R,ye as S,ge as T,Ee as W,me as X,ke as a,X as b,le as c,oe as d,re as e,V as f,J as g,W as h,pe as i,se as j,Y as k,B as l,K as m,ue as n,Me as o,Se as p,we as q,Ae as r,Z as s,he as t,ae as u,H as v,fe as w,Ne as x,be as y,Te as z};
